Write a function to find the longest common prefix string amongst an array of strings.
