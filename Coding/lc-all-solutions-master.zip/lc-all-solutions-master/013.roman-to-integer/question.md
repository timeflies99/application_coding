Given a roman numeral, convert it to an integer.

Input is guaranteed to be within the range from 1 to 3999.