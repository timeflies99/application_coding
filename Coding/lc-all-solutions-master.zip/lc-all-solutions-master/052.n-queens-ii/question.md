Follow up for N-Queens problem.

Now, instead outputting board configurations, return the total number of distinct solutions.

