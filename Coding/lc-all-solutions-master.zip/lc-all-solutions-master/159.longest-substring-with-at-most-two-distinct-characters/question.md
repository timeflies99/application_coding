
Given a string, find the length of the longest substring T that contains at most 2 distinct characters.



For example,

Given s = “eceba”,



T is "ece" which its length is 3.
