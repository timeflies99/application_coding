Given a binary tree, count the number of uni-value subtrees.
A Uni-value subtree means all nodes of the subtree have the same value.


For example:
Given binary tree,

              5
             / \
            1   5
           / \   \
          5   5   5



return 4.
