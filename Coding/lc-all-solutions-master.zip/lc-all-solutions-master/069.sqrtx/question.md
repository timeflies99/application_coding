Implement int sqrt(int x).

Compute and return the square root of x.