Implement pow(x, n).
