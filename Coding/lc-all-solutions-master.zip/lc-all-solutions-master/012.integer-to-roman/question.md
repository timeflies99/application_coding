Given an integer, convert it to a roman numeral.


Input is guaranteed to be within the range from 1 to 3999.