### 题目描述
用两个栈来实现一个队列，完成队列的Push和Pop操作。 队列中的元素为int类型。

### 思路
一个栈用来存储
pop时弹出stack2，stack2为空，pop出stack1存储在stack2中