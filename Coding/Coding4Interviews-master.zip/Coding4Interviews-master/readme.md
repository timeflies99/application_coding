# 聊聊算法刷题

算法题本身是公司筛选人才的一种手段，对公司来说易操作、成本低(找个题库谁都能做面试官)、人才损失率低(能通过算法题的，做业务问题不大)。

作为找工作一方要接受游戏规则，但是心里应该明白刷题本身是没什么价值的。

个人认为应该集中花时间刷两个月左右即可。

笔者面试准备之余写了篇小结：[面试必刷-《剑指offer》刷题小结](https://mp.weixin.qq.com/s?__biz=MzU4OTczNTg2OQ==&mid=2247484491&idx=1&sn=d9b03c21782678bac8b3e825535f4224&chksm=fdc9b699cabe3f8fca01456fc2f1d23d9b8c27efc7582fdf8d3d42d05e97e8e30657776c5baf&scene=21&token=1446701999&lang=zh_CN#wechat_redirect)








