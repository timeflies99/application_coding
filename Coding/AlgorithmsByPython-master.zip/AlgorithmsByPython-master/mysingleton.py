# 单例模式
class My_Singleton(object):
    def foo(self):
        pass
my_singleton = My_Singleton()