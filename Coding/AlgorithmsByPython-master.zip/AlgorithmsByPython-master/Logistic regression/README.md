# #Python实现逻辑斯蒂回归
使用Python实现Logistic回归，代码思路来源于[机器学习实战](https://github.com/pbharrin/machinelearninginaction)，改正了原代码中的一些在Python3.5上运行存在的bug。对随机梯度上升法进行了简单的修改。