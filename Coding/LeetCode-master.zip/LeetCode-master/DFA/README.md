# DFA确定有限状态机

解释：


具体题目：

* 65. Valid Number

图解：

![][1]

![][2]


[1]: http://xuelangzf-github.qiniudn.com/LeetCode65_ValidNumber.png 
[2]: http://xuelangzf-github.qiniudn.com/LeetCode65_State_change.png 
